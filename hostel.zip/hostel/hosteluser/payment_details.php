<?php
include('includes/checklogin.php');
check_login();
?>
<!DOCTYPE html>
<html lang="en">
<?php @include("includes/head.php");?>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <?php @include("includes/header.php");?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:../../partials/_sidebar.html -->
            <?php @include("includes/sidebar.php");?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">


                    <form method="post" action="payment/pgRedirect.php?">
                        <div class="table-responsive p-3">
                            <table class="table align-items-center table-flush table-hover table-bordered"
                                id="dataTableHover">
                                <thead>
                                    <tr>
                                        <th>Sno.</th>
                                        <th>Regiter No.</th>
                                        <th>booking id.</th>

                                        <th>Room No.</th>
                                        <th>Duration</th>
                                        <th>Fees (PM)</th>
                                        <th>Total Fees</th>
                                        <th>Posting Date </th>
                                        <th class=" Text-center" style="width: 15%;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>



                                    <?php
                              $reg_no=$_SESSION['regno'];
                              $sql="SELECT * from registration where regno='$reg_no' ORDER BY id DESC";
                              $query = $dbh -> prepare($sql);
                              $query->execute();
                              $results=$query->fetchAll(PDO::FETCH_OBJ);
                              $cnt=1;

                              if($query->rowCount() > 0)
                              {
                                foreach($results as $row)
                                { 

                                  ?>
                                    <tr>
                                        <td><?php echo $cnt;;?></td>
                                        <td><?php echo $row->regno;?></td>
                                        <td><?php echo $row->id;?></td>
                                        <td><?php echo $row->roomno;?></td>
                                        <td><?php echo $row->duration;?></td>
                                        <td><?php echo $row->feespm;?></td>
                                        <?php $free=$row->feespm;
                                           $dr=$row->duration; 
                                           $booking=$row->id; 
                                          
                                      ?>
                                        <td><?php echo $frees=$free*$dr;?></td>
                                        <td class="text-center">
                                            <?php  echo htmlentities(date("d-m-Y", strtotime($row->postingDate)));?>
                                        </td>
                                        <td class=" text-center">
                                            <?php $sql2="SELECT * from payment where bookingid='$booking' ";
                                        $query2 = $dbh -> prepare($sql2);
                                        $query2->execute();
                                        $results2=$query2->fetchAll(PDO::FETCH_OBJ);
                                        foreach($results2 as $row2)
                                { 
                                                if($row2->txnstatus=="TXN_SUCCESS")
                                               
                                          {
                                            $showb=1;
                                            
                                         
                                         }
                                        
                                }
                                if($showb==1){
                                  echo "<b class='text-success'>Payment Paid</b>";
                                 }
                                  else
                                  {?>


                                            <input type="hidden" id="ORDER_ID" name="ORDER_ID"
                                                value="<?php echo $row->id; ?>">
                                            <input type="hidden" id="CUST_ID" name="CUST_ID"
                                                value="<?php echo $row->regno; ?>">
                                            <input type="hidden" id="TXN_AMOUNT" name="TXN_AMOUNT"
                                                value="<?php echo $frees; ?>">
                                            <button type="submit" name="payment"
                                                class="btn btn-sm btn-primary btn-fw mr-2">Process Payment</button>

                                            <!-- <a href="#"  class=" edit_data4" id="<?php echo  ($row->id); ?>" title="click to edit">Process to Payment</a> -->
                                            <?php }             ?>

                                        </td>
                                    </tr>
                                    <?php 
                                  $cnt=$cnt+1;
                                }
                              }
                              ?>


                                </tbody>
                            </table>
                        </div>
                    </form>
                    <!-- content-wrapper ends -->
                    <!--  start  modal -->
                    <div id="editData4" class="modal fade">
                        <div class="modal-dialog modal-md">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Edit Room details</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body" id="info_update4">
                                    <?php @include("view_payment.php");?>
                                </div>
                                <div class="modal-footer ">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                </div>
                                <!-- /.modal-content -->
                            </div>
                            <!-- /.modal-dialog -->
                        </div>
                        <!-- /.modal -->
                    </div>
                    <!--   end modal -->
                    <!-- partial:../../partials/_footer.html -->
                    <?php @include("includes/footer.php");?>
                    <!-- partial -->
                </div>
                <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
        </div>
        <!-- container-scroller -->
        <?php @include("includes/foot.php");?>
        <!-- End custom js for this page -->

        <script type="text/javascript">
        $(document).ready(function() {
            $(document).on('click', '.edit_data4', function() {
                var edit_id4 = $(this).attr('id');
                $.ajax({
                    url: "view_payment.php",
                    type: "post",
                    data: {
                        edit_id4: edit_id4
                    },
                    success: function(data) {
                        $("#info_update4").html(data);
                        $("#editData4").modal('show');
                    }
                });
            });
        });
        </script>
</body>

</html>